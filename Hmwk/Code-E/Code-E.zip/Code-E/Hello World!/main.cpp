/* 
 * Author: Matthew Madrigal
 * Date:September 15th 2025, 11:05pm
 * Purpose: To say hello world and learn how to get the correct formatting!
 */

//System Libraries Here
#include <iostream>
using namespace std;

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Output Located Here
    cout << endl << "   Hello World!  " << endl << endl;

    //Exit
    return 0;
}